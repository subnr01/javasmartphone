package com.nihar.java_assignment.foureverhungry;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SearchPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);
    }

    public void goToListings(View sender) {
        Intent intent = new Intent(SearchPage.this, ListingsPage.class);
        startActivity(intent);
        finish();
    }
}
