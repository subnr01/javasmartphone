package com.nihar.java_assignment.foureverhungry;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ListingsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listings_page);
    }
}
