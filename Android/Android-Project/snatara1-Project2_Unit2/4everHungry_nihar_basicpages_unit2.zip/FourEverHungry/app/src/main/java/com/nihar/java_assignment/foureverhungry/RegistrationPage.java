package com.nihar.java_assignment.foureverhungry;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class RegistrationPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);
    }
    public void goToWelcomePage(View sender) {
        Intent intent = new Intent(RegistrationPage.this, WelcomePage.class);
        startActivity(intent);
        finish();
    }
}
