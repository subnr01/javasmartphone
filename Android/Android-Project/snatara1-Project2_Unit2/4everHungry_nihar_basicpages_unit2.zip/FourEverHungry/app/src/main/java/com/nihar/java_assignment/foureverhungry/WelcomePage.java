package com.nihar.java_assignment.foureverhungry;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class WelcomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToSearchPage(View sender) {
        Intent intent = new Intent(WelcomePage.this, SearchPage.class);
        startActivity(intent);
        finish();
    }
    }
