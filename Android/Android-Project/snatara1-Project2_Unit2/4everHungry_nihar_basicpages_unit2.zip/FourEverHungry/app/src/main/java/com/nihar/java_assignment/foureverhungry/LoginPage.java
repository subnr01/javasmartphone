package com.nihar.java_assignment.foureverhungry;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class LoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
    }

    public void goToWelcomePage(View sender) {
        Intent intent = new Intent(LoginPage.this, WelcomePage.class);
        startActivity(intent);
        finish();
    }
    public void goToRegistrationPage(View sender) {
        Intent intent = new Intent(LoginPage.this, RegistrationPage.class);
        startActivity(intent);
        finish();
    }

}
