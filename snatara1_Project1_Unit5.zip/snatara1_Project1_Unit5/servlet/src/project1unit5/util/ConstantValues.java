/**
 * Author: Subramanian N
 * Andrew id: snatara1
 */
package project1unit5.util;





public final class ConstantValues {
	 public static final int PORT = 1234; 
	 public static final String automobileFileList = "Automobiles.txt";
	
	/* No instantiation */
	private ConstantValues() {};
}