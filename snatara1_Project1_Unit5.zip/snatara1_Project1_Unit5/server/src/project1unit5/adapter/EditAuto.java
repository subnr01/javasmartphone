/**
 * Author: Subramanian N
 * Andrew id: snatara1
 */

package project1unit5.adapter;

import project1unit5.scale.EditOptionEnum;


public interface EditAuto {
	/*
	 * Interface to multithreading
	 */
	
	public void edit(EditOptionEnum editOptionEnum,String[] args);

}
