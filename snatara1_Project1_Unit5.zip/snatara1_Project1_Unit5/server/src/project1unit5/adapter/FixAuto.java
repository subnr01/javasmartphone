/**
 * Author: Subramanian N
 * Andrew id: snatara1
 */

package project1unit5.adapter;


public interface FixAuto {
	/*
	 * Interface to fix exceptions
	 */
	public void fix(int errno);
}
