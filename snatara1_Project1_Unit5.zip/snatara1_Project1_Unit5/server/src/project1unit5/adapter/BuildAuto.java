/**
 * Author: Subramanian N
 * Andrew id: snatara1
 */

package project1unit5.adapter;

import project1unit5.server.*;

/*
 * Empty class implementing lots of interfaces
 */
public class BuildAuto extends ProxyAutomobile implements CreateAuto,
		UpdateAuto, FixAuto ,EditAuto,  AutoServer{

}
