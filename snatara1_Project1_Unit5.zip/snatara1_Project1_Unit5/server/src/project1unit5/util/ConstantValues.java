/**
 * Author: Subramanian N
 * Andrew id: snatara1
 */
package project1unit5.util;





public final class ConstantValues {
	 public static final int SERVER_PORT = 1234; 
	 public static final boolean DEBUG = false; 
	 
	/* No instantiation */
	private ConstantValues() {};
}